package alice;

import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class Test {
    public static void main(String[] args) throws Throwable {
        try (JarFile jar = new JarFile("C:\\Users\\herob\\IdeaProjects\\AliceAPI\\forge-1.12.2-14.23.5.2864.jar")) {
            Manifest manifest = jar.getManifest();
            System.out.println(manifest.getMainAttributes().getValue("Tweak-Class"));
        }
    }
}
